#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
double d=65.0; 
cout<<"Enter a decimal value: ";
cin>>d; 
cout<<&d;   //dereferencing 

}
